import org.junit.Test;
import static prg.junit.Assert;

public class ProductTest {
    private String [] products = {
        "Cozy Nights Monarch"
        "Restonic Barbados"
        "Sealy Phuket"
};
public void GetTotalProductSales_WithValidData_ReturnsCorrectValue(){
    Product(produvt = new Product(products,sales));
    int expected = 153;
    int actual = product .Get TotalProductsSold();
    assertEquals(expected,actual);
    }
@test
public void 
FetAverageSales_WithValidData_ReturnsCorrectValue(){
    product product = new Product (product,sales);
    double expected = 17.0;
    double actual = product.GetAverageProductSold();
    assertEquals(expected,actual,0.01);
}
}