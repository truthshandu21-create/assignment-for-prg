import java.util.ArrayList;
import java.util.Scanner;

class Product {
    String name;
    double price;
    int quantity;
    
    Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
}

class Book {
    String title;
    String author;
    boolean available;
    
    Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.available = true; // new books are available by default
    }
}

public class Exercise2 {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Book> library = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1. Shopping Cart");
            System.out.println("2. Library System");
            System.out.println("3. Exit");
            System.out.print("Choose: ");
            int choice = sc.nextInt();
            sc.nextLine(); // clear buffer
            
            if (choice == 1) shoppingCart();
            else if (choice == 2) librarySystem();
            else if (choice == 3) break;
            else System.out.println("Invalid choice");
        }
    }

    // ========== 1. SHOPPING CART ==========
    public static void shoppingCart() {
        ArrayList<Product> cart = new ArrayList<>();
        // Example items
        cart.add(new Product("Milk", 25.50, 2));
        cart.add(new Product("Bread", 18.00, 1));
        cart.add(new Product("Rice", 45.99, 1));
        cart.add(new Product("Eggs", 32.00, 1));

        System.out.println("\n--- SHOPPING CART ---");
        double subtotal = 0;
        for (Product p : cart) {
            double total = p.price * p.quantity;
            subtotal += total;
            System.out.println(p.name + " | R" + p.price + " x " + p.quantity + " = R" + total);
        }

        double vat = subtotal * 0.15; // 15% VAT
        double grandTotal = subtotal + vat;

        System.out.println("---------------------------");
        System.out.println("Subtotal: R" + String.format("%.2f", subtotal));
        System.out.println("VAT (15%): R" + String.format("%.2f", vat));
        System.out.println("Grand Total: R" + String.format("%.2f", grandTotal));
    }

    // ========== 2. LIBRARY SYSTEM ==========
    public static void librarySystem() {
        while (true) {
            System.out.println("\n--- LIBRARY MENU ---");
            System.out.println("1. Add Book");
            System.out.println("2. Borrow");
            System.out.println("3. Return");
            System.out.println("4. Search");
            System.out.println("5. Display Available Books");
            System.out.println("6. Display Borrowed Books");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1: addBook(); break;
                case 2: borrowBook(); break;
                case 3: returnBook(); break;
                case 4: searchBook(); break;
                case 5: displayAvailable(); break;
                case 6: displayBorrowed(); break;
                case 7: return;
                default: System.out.println("Invalid choice");
            }
        }
    }

    public static void addBook() {
        System.out.print("Enter Book Title: ");
        String title = sc.nextLine();
        System.out.print("Enter Author: ");
        String author = sc.nextLine();
        library.add(new Book(title, author));
        System.out.println("Book added successfully!");
    }

    public static void borrowBook() {
        System.out.print("Enter Book Title to Borrow: ");
        String title = sc.nextLine();
        for (Book b : library) {
            if (b.title.equalsIgnoreCase(title) && b.available) {
                b.available = false;
                System.out.println("You borrowed: " + b.title);
                return;
            }
        }
        System.out.println("Book not available.");
    }

    public static void returnBook() {
        System.out.print("Enter Book Title to Return: ");
        String title = sc.nextLine();
        for (Book b : library) {
            if (b.title.equalsIgnoreCase(title) && !b.available) {
                b.available = true;
                System.out.println("You returned: " + b.title);
                return;
            }
        }
        System.out.println("Book not found or already available.");
    }

    public static void searchBook() {
        System.out.print("Enter Book Title to Search: ");
        String title = sc.nextLine();
        for (Book b : library) {
            if (b.title.toLowerCase().contains(title.toLowerCase())) {
                System.out.println("Found: " + b.title + " by " + b.author + " | Available: " + b.available);
     
