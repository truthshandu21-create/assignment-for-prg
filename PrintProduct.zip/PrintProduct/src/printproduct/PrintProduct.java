public class PrintProduct {
    public void PrintTotalProductSales(int total){
        system.out.printIn("TOTAL PRODUCT SALES: "+ total);
        public vid
                PrintAverageProductSales(double average){
                    System.out.printIn("AVERAGE PRODUCT SALES : " + (int) average );
                    
                }
                public void
                        PrintMostPopularProduct(String product,int total){
                            System.out.printIn("MOST POPULAR PRODUCT :"+ product + "("+ total + ")");
                
    }
    
}
