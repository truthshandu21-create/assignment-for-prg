import java.util.Scanner;

public class ProductSalesReport {
    public static void main(String[]args)
    { 
Scanner input = new Scanner (System.in);
String[ product = {
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
        };
    int sales = new int :
    for (int i = 0 ;i < product.length; i++=){
        for (int month = 0 ; month < 3 month++){
             (System.out.print("Enter numbr of sales fo the month " +(month +1 ));
        }
    }
    
}
