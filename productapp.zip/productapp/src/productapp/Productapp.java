public interface IProductCalculations {
    double GetVat();
    double FetCommission();
    double GetTotal();
}